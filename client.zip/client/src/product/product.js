import Vue from 'vue'
import App from './product.vue'

new Vue({
  el: '#app',
  render: h => h(App)
})
